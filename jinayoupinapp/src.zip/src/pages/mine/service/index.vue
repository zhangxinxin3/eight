<template>
    <div>
        <p>客服服务电话：周一至周日(24小时)</p>
        <p>客服电话：4008 0000 53</p>
    </div>
</template>

<script>
export default {

}
</script>

<style lang="scss" scoped>
div{
    display: flex;
    flex-direction: column;
    width: 100%;
    height: 100%;
    padding: 20rpx;
    p{
        height: 100rpx;
        line-height: 100rpx;
    }
}
</style>
