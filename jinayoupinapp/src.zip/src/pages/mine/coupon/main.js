import Vue from 'vue'
import App from './coupon'

const app = new Vue(App)
app.$mount()
