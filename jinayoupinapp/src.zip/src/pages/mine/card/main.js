import Vue from 'vue'
import App from './card'

const app = new Vue(App)
app.$mount()
